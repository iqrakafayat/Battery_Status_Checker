﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Speech;
//using System.Timers;
//using System.Media;
using System.Speech.Recognition;
using System.Speech.Synthesis;

namespace WindowsFormsApplication9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ShowPowerStatus();
        }
        void ShowPowerStatus()
        {
            // Initialize a new instance of the SpeechSynthesizer.
            SpeechSynthesizer speech = new SpeechSynthesizer();

            // it is used as a property on System.Windows.Forms.SystemInformation. 
            PowerStatus status = SystemInformation.PowerStatus;
            txtChargeStatus.Text = status.BatteryLifePercent.ToString("P0");
            if (status.BatteryLifePercent  <  40)
            {
                speech.Speak("Battery is low please put on charge ");
                MessageBox.Show("Battery Is below 40% ");
            }
            if (status.BatteryLifePercent == 50)
            {
                    speech.Speak("50% charged");
                    MessageBox.Show("Battery Is 50% charged");
            }
            if (status.BatteryLifePercent == 100)
            {
                        speech.Speak("Battery is fully charged");
                        MessageBox.Show("Battery Is FULLY charged.Plug off your charger");
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
